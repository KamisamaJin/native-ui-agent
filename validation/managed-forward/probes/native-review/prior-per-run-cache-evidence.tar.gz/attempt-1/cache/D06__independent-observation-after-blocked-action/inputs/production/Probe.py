CAPABILITY = 'source-declaration'
