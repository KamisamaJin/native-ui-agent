def bridge(): return None
