package org.nativeobserver

import androidx.compose.runtime.Composable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.int
import com.example.reply.ui.theme.ContrastAwareReplyTheme
import com.example.reply.ui.components.business.*

private fun JsonObject.s(k: String) = getValue(k).jsonPrimitive.content
private fun JsonObject.i(k: String) = getValue(k).jsonPrimitive.int
private fun JsonObject.b(k: String) = getValue(k).jsonPrimitive.boolean

object ObserverBridge {
    @Composable
    fun Content(input: JsonObject, onEvent: (String) -> Unit) {
        val decoded = EquipmentReturnFixture(
            entityId = input.s("entityId"),
            entityTitle = input.s("entityTitle"),
            description = input.s("description"),
            dataBearing = input.b("dataBearing"),
            restockAllowed = input.b("restockAllowed"),
            repairAllowed = input.b("repairAllowed"),
            recycleAllowed = input.b("recycleAllowed"),
            restockDetail = input.s("restockDetail"),
            repairDetail = input.s("repairDetail"),
            recycleDetail = input.s("recycleDetail"),
        )
        ContrastAwareReplyTheme(darkTheme = false, dynamicColor = false) {
            EquipmentReturnPanel(fixture = decoded, onEvent = onEvent)
        }
    }
}
