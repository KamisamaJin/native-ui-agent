# Frozen rendered-fill policy

All source colors are opaque #AARRGGBB, painted by the component itself. No alpha model, added epsilon, expected override, or color-dependent region selection is permitted. Host canvas color is not scored as component paint.

Panel: normalized [0.018,0.06,0.035,0.94] of full panel semantic box; visible_fragment; minimum12pixels; support0.95; RGB channel tolerance0. At358pt/dp width this x-strip is approximately6–12pt/dp: inside the white16pt/dp inset and outside every child. Its vertical range excludes rounded ends. Tall panels use eligible visible fragments of this same approved gutter.

Primary: [0.04,0.25,0.10,0.75]; fully_visible; minimum20pixels; support0.95; tolerance0. This left interior band is clear of the fixed short centered label and8pt/dp corner curves. Primary labels are fixed by each task and never supplied as long caller text.

Every option row: [0.92,0.25,0.97,0.75]; fully_visible; minimum20pixels; support0.95; tolerance0. A trailing24pt/dp gutter is intentionally free of text, marks, and icons. Labels/detail copy stop to its left; selection marks are at the leading edge. The sample excludes rounded top/bottom corners. A partial long row does not earn a fill pass where full visibility is required.

These independently suitable regions were fixed before candidate pixels exist. They establish dominant rendered sRGB fill only, not computed SwiftUI attributes, whole-canvas coverage, text ink, typography, effective padding, or physical hit area. Insufficient eligible support remains unknown. Semantic control facts, callbacks, rendered fill atoms and qualitative visual atoms stay separate.
